import { useState } from "react";
import { 
  Shield, 
  Terminal, 
  Settings, 
  Layers, 
  BookOpen, 
  Cpu, 
  Network, 
  FileText, 
  Percent,
  CheckCircle2,
  Lock,
  ExternalLink
} from "lucide-react";
import ConfigAuditor from "./components/ConfigAuditor";
import PortScannerVisualizer from "./components/PortScannerVisualizer";
import CveLibrary from "./components/CveLibrary";
import CvssCalculator from "./components/CvssCalculator";

export default function App() {
  const [activeTab, setActiveTab] = useState<"auditor" | "scanner" | "cvss" | "cve">("auditor");

  return (
    <div className="min-h-screen bg-slate-950 font-sans selection:bg-indigo-500 selection:text-white text-slate-200">
      
      {/* Upper Security Header Banner */}
      <header className="border-b border-slate-900 bg-slate-950/80 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            
            {/* Title & Branding */}
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="relative flex h-2.5 w-2.5 shrink-0">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-indigo-500"></span>
                </span>
                <h1 className="text-xl font-bold tracking-tight text-white font-mono uppercase">SECURITY AUDIT & THEORY LAB</h1>
              </div>
              <p className="text-[11px] text-slate-400 leading-normal max-w-xl">
                An interactive educational sandbox for learning vulnerability assessment, static configuration auditing, TCP network port scanning mechanics, and standard CVSS scoring vectors.
              </p>
            </div>

            {/* Compliance Mode Indicator Badge */}
            <div className="flex items-center gap-2 text-[10px] font-mono bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg text-slate-400 select-none shrink-0">
              <span className="text-indigo-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-indigo-400" />
                Dual-Use Compliance Mode
              </span>
              <span className="text-slate-600">|</span>
              <span className="text-emerald-400 font-semibold flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
                100% EDUCATIONAL & SAFE
              </span>
            </div>

          </div>
        </div>
      </header>

      {/* Main Container Area */}
      <main className="max-w-7xl mx-auto px-4 py-8 space-y-8">
        
        {/* Lab Navigation Tabs */}
        <div className="flex border-b border-slate-900 overflow-x-auto gap-1 scrollbar-none select-none">
          
          <button
            onClick={() => setActiveTab("auditor")}
            className={`flex items-center gap-2 px-5 py-3.5 border-b-2 font-medium text-xs font-mono uppercase tracking-wider transition-all duration-200 shrink-0 cursor-pointer ${
              activeTab === "auditor"
                ? "border-indigo-500 text-white bg-indigo-950/10"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-800"
            }`}
          >
            <FileText className="w-4 h-4 text-indigo-400" />
            Static Configuration Auditor
          </button>

          <button
            onClick={() => setActiveTab("scanner")}
            className={`flex items-center gap-2 px-5 py-3.5 border-b-2 font-medium text-xs font-mono uppercase tracking-wider transition-all duration-200 shrink-0 cursor-pointer ${
              activeTab === "scanner"
                ? "border-indigo-500 text-white bg-indigo-950/10"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-800"
            }`}
          >
            <Network className="w-4 h-4 text-indigo-400" />
            TCP Handshake & Port Simulator
          </button>

          <button
            onClick={() => setActiveTab("cvss")}
            className={`flex items-center gap-2 px-5 py-3.5 border-b-2 font-medium text-xs font-mono uppercase tracking-wider transition-all duration-200 shrink-0 cursor-pointer ${
              activeTab === "cvss"
                ? "border-indigo-500 text-white bg-indigo-950/10"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-800"
            }`}
          >
            <Percent className="w-4 h-4 text-indigo-400" />
            CVSS Severity Calculator
          </button>

          <button
            onClick={() => setActiveTab("cve")}
            className={`flex items-center gap-2 px-5 py-3.5 border-b-2 font-medium text-xs font-mono uppercase tracking-wider transition-all duration-200 shrink-0 cursor-pointer ${
              activeTab === "cve"
                ? "border-indigo-500 text-white bg-indigo-950/10"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-800"
            }`}
          >
            <BookOpen className="w-4 h-4 text-indigo-400" />
            CVE Reference Encyclopedia
          </button>

        </div>

        {/* Tab Modules Content Switcher */}
        <div className="space-y-6">
          
          {activeTab === "auditor" && <ConfigAuditor />}
          
          {activeTab === "scanner" && <PortScannerVisualizer />}
          
          {activeTab === "cvss" && <CvssCalculator />}
          
          {activeTab === "cve" && <CveLibrary />}

        </div>

        {/* Informational Guidance Footer Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
          
          {/* Box 1: Why Security Auditing Matters */}
          <div className="bg-slate-900/40 border border-slate-850 p-5 rounded-xl space-y-2">
            <h3 className="text-xs font-bold font-mono text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
              <Lock className="w-4 h-4" />
              The Security Lifecycle & Audit Best Practices
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed font-sans">
              Modern penetration testing is not simply about probing live ports. Over 80% of actual web application compromises stem from **insecure configurations**—such as baking environment database keys directly into code repos or using outdated Docker parent containers. Proactive auditing is the single most efficient defense line.
            </p>
          </div>

          {/* Box 2: Secure Policy / Safe Learning Info */}
          <div className="bg-slate-900/40 border border-slate-850 p-5 rounded-xl space-y-2">
            <h3 className="text-xs font-bold font-mono text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4" />
              Educational Outcome Compliance
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed font-sans">
              To guarantee system safety and avoid generating actionable reconnaissance exploits, this application functions as a **theoretical simulator sandbox**. All Nginx, Dockerfile, and dependency scans run through deterministic local linter parsers, and all packet handshakes are visual flow representations.
            </p>
          </div>

        </div>

      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-8 text-center text-xs text-slate-500 font-mono">
        <div className="max-w-7xl mx-auto px-4 space-y-1.5">
          <p>Designed for secure local educational analysis, compliant with FIRST.org CVSS guidelines and OWASP Top 10 vectors.</p>
          <p>© 2026 Security Auditor & Theory Lab. Promoting defense-in-depth and responsible penetration training.</p>
        </div>
      </footer>

    </div>
  );
}
