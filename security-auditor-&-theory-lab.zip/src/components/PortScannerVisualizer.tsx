import { useState, useEffect, useRef } from "react";
import { 
  Terminal, 
  Play, 
  Cpu, 
  Network, 
  Info, 
  ArrowRight, 
  Check, 
  RefreshCw,
  Server,
  Activity,
  HelpCircle
} from "lucide-react";
import { PacketAnimationState, PacketType, ScanType } from "../types";

// Simulated network targets for learning
const TARGETS = [
  {
    id: "target_linux_prod",
    name: "Production Web Server (Linux/Ubuntu)",
    ip: "10.0.4.85",
    os: "Ubuntu 20.04 LTS (Kernel 5.4)",
    ports: [
      { number: 22, service: "SSH", state: "open" as const, banner: "SSH-2.0-OpenSSH_8.2p1 Ubuntu-4ubuntu0.5", risk: "Medium (Exposed management gate)" },
      { number: 80, service: "HTTP", state: "open" as const, banner: "nginx/1.18.0", risk: "Low (HTTP redirected to HTTPS)" },
      { number: 443, service: "HTTPS", state: "open" as const, banner: "nginx/1.18.0 (TLS v1.2 / TLS v1.3)", risk: "None (Securely configured)" },
      { number: 3306, service: "MySQL", state: "filtered" as const, risk: "Secure (Blocked by external cloud firewall)" },
      { number: 8080, service: "HTTP-Alt", state: "closed" as const, risk: "None (Service not listening)" }
    ]
  },
  {
    id: "target_iot_cam",
    name: "Industrial IoT Camera (RTOS Firmware)",
    ip: "192.168.1.140",
    os: "BusyBox / Embedded Linux v2.6",
    ports: [
      { number: 23, service: "Telnet", state: "open" as const, banner: "Busybox telnetd v1.12.1 (Admin password: admin)", risk: "Critical (Cleartext credentials over unencrypted telnet!)" },
      { number: 80, service: "HTTP", state: "open" as const, banner: "GoAhead WebServer v2.5.0", risk: "High (GoAhead RCE Vulnerabilities CVE-2017-17562)" },
      { number: 554, service: "RTSP", state: "open" as const, banner: "Live555 Streaming Media server", risk: "High (Unauthenticated RTSP stream access)" },
      { number: 443, service: "HTTPS", state: "closed" as const, risk: "None" }
    ]
  }
];

export default function PortScannerVisualizer() {
  const [selectedTargetId, setSelectedTargetId] = useState<string>("target_linux_prod");
  const [scanType, setScanType] = useState<ScanType>("syn");
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [scanProgress, setScanProgress] = useState<number>(0);
  const [activePortIndex, setActivePortIndex] = useState<number>(-1);
  const [consoleLogs, setConsoleLogs] = useState<string[]>([]);
  const [scanResults, setScanResults] = useState<{ number: number; service: string; state: string; banner?: string; risk?: string }[]>([]);
  const [animationState, setAnimationState] = useState<PacketAnimationState | null>(null);
  const [showExplanation, setShowExplanation] = useState<boolean>(true);

  const logsEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll console logs
  useEffect(() => {
    if (logsEndRef.current) {
      logsEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [consoleLogs]);

  const target = TARGETS.find(t => t.id === selectedTargetId) || TARGETS[0];

  // Run the simulated port scan loop
  const handleInitiateScan = async () => {
    if (isScanning) return;
    
    setIsScanning(true);
    setScanProgress(0);
    setActivePortIndex(-1);
    setScanResults([]);
    setAnimationState(null);

    const scanTypeUpper = scanType.toUpperCase();
    const startLogs = [
      `Starting CryptoShield Port Scanner v3.4.1 at ${new Date().toLocaleTimeString()}`,
      `Initiating ${scanTypeUpper} Port Scan against ${target.name} (${target.ip})...`,
      `OS Detection Enabled: Target suspected fingerprint matches ${target.os}`,
      `Probing ${target.ports.length} common security ports...`,
      `----------------------------------------------------------------------`
    ];
    setConsoleLogs(startLogs);

    // Scan each port sequentially for visual feedback
    for (let i = 0; i < target.ports.length; i++) {
      const port = target.ports[i];
      setActivePortIndex(i);
      
      setConsoleLogs(prev => [...prev, `[>] Probing Port ${port.number} (${port.service})...`]);

      // Phase 1: Trigger packet visualization from client to target
      await runPacketAnimation("scanner", "SYN", `[SYN] Flag set. Scanning Port ${port.number}`);
      
      // Phase 2: Target responses based on state
      if (port.state === "open") {
        if (scanType === "syn") {
          // SYN scan receives SYN-ACK, then client responds with RST to cancel connection
          await runPacketAnimation("target", "SYN-ACK", `[SYN-ACK] Port Active! Flag received from Port ${port.number}`);
          await runPacketAnimation("scanner", "RST", `[RST] Stealth-scan abort. Terminating socket connection.`);
          setConsoleLogs(prev => [
            ...prev,
            `  [+] Port ${port.number}/TCP is OPEN!`,
            port.banner ? `  [+] Service Banner Detected: "${port.banner}"` : `  [+] Standard service: ${port.service}`
          ]);
        } else if (scanType === "connect") {
          // Full Connect scan does 3-way handshake SYN -> SYN-ACK -> ACK, then closes politely
          await runPacketAnimation("target", "SYN-ACK", `[SYN-ACK] Port is listening.`);
          await runPacketAnimation("scanner", "ACK", `[ACK] Establishing full TCP Handshake.`);
          await runPacketAnimation("scanner", "RST", `[RST-FIN] Polite closing of established connection.`);
          setConsoleLogs(prev => [
            ...prev,
            `  [+] Port ${port.number}/TCP is OPEN! (TCP Handshake Completed Successfully)`,
            port.banner ? `  [+] Banner Grabbing Success: "${port.banner}"` : `  [+] Service matches: ${port.service}`
          ]);
        } else {
          // UDP Scan (different mechanic)
          await runPacketAnimation("scanner", "UDP", `Sending raw UDP Datagram...`);
          setConsoleLogs(prev => [...prev, `  [?] UDP query sent. Awaiting timeout response (UDP is connectionless)...`]);
          await delay(800);
          setConsoleLogs(prev => [...prev, `  [+] Port ${port.number}/UDP responded or timed out silently (Suspected OPEN/FILTERED)`]);
        }
      } else if (port.state === "closed") {
        // Closed ports respond immediately with RST-ACK
        await runPacketAnimation("target", "RST", `[RST] Connection Refused. Flag received from Port ${port.number}`);
        setConsoleLogs(prev => [...prev, `  [-] Port ${port.number}/TCP is CLOSED (Server actively rejected connection).`]);
      } else {
        // Filtered ports drop packets (Firewall) -> Client experiences timeout
        await runPacketAnimation("target", "TIMEOUT", `[DROP] Firewall dropped packet. Connection attempt timed out...`);
        setConsoleLogs(prev => [
          ...prev,
          `  [-] Port ${port.number}/TCP is FILTERED (No response received. Packets dropped by Firewall/IDS).`
        ]);
      }

      // Add to results table
      setScanResults(prev => [...prev, {
        number: port.number,
        service: port.service,
        state: port.state,
        banner: port.banner,
        risk: port.risk
      }]);

      setScanProgress(Math.round(((i + 1) / target.ports.length) * 100));
      await delay(400);
    }

    setConsoleLogs(prev => [
      ...prev,
      `----------------------------------------------------------------------`,
      `Scan Completed. ${target.ports.filter(p => p.state === "open").length} open ports discovered.`,
      `Vulnerability Mapping completed. Generate your security action dashboard below.`
    ]);
    setIsScanning(false);
    setActivePortIndex(-1);
    setAnimationState(null);
  };

  // Run a visual step-by-step packet transition
  const runPacketAnimation = async (sender: "scanner" | "target", type: PacketType, desc: string) => {
    setAnimationState({
      step: sender === "scanner" ? 1 : 2,
      sender,
      type,
      flags: getFlagsText(type),
      desc,
      active: true
    });
    await delay(1200); // Wait for user to read/view animation
  };

  const getFlagsText = (type: PacketType) => {
    switch (type) {
      case "SYN": return "[SYN: 1, ACK: 0]";
      case "SYN-ACK": return "[SYN: 1, ACK: 1]";
      case "ACK": return "[SYN: 0, ACK: 1]";
      case "RST": return "[RST: 1, ACK: 1]";
      case "UDP": return "[Connectionless Datagram]";
      case "ICMP_UNREACH": return "[ICMP Type 3 (Unreachable)]";
      default: return "[None]";
    }
  };

  const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

  return (
    <div id="port-scanner-visualizer" className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl space-y-6">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-500/10 rounded-lg animate-pulse">
            <Network className="w-5 h-5 text-indigo-400" />
          </div>
          <div>
            <h2 className="text-xl font-bold tracking-tight text-white">Network & Port Scanner Simulator</h2>
            <p className="text-xs text-slate-400">Learn network discovery, handshakes, and firewall mechanics</p>
          </div>
        </div>

        <button
          onClick={() => setShowExplanation(!showExplanation)}
          className="text-xs flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-800 bg-slate-950 text-slate-400 hover:text-white transition cursor-pointer"
        >
          <HelpCircle className="w-3.5 h-3.5" />
          {showExplanation ? "Hide Explanation" : "Explain Scan Types"}
        </button>
      </div>

      {/* Educational scan types explanation section */}
      {showExplanation && (
        <div className="bg-slate-950 border border-indigo-950/40 p-4 rounded-xl grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="space-y-1.5">
            <h4 className="font-bold text-indigo-400 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span>
              TCP SYN Scan (Stealth)
            </h4>
            <p className="text-slate-400 leading-normal">
              Sends a single **SYN** (Synchronize) packet. If the port replies with **SYN-ACK**, the scanner knows the port is open but immediately sends a **RST** (Reset) to close it *before* completing the 3-way handshake. This avoids generating application logs.
            </p>
          </div>
          <div className="space-y-1.5">
            <h4 className="font-bold text-emerald-400 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
              TCP Connect Scan
            </h4>
            <p className="text-slate-400 leading-normal">
              Completes the **full 3-Way Handshake** (SYN ➔ SYN-ACK ➔ ACK). Because it completes the socket connection, it triggers application logs and is easily spotted by host intrusion detection systems, but does not require root privileges to run.
            </p>
          </div>
          <div className="space-y-1.5">
            <h4 className="font-bold text-amber-400 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
              Firewall & Filtered Ports
            </h4>
            <p className="text-slate-400 leading-normal">
              When a firewall stands between the scanner and server, it often **drops** the packets entirely. Because no response packet arrives, the scanner sits waiting until a timeout triggers, classifying the port as **Filtered**.
            </p>
          </div>
        </div>
      )}

      {/* Target Setup Configuration */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Target selectors & options */}
        <div className="lg:col-span-4 bg-slate-950 rounded-xl p-5 border border-slate-850 flex flex-col justify-between space-y-4">
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-[10px] uppercase font-mono tracking-wider font-bold text-slate-400">
                1. Select Educational Lab Node
              </label>
              <select
                value={selectedTargetId}
                onChange={(e) => {
                  setSelectedTargetId(e.target.value);
                  setScanResults([]);
                  setConsoleLogs([]);
                }}
                disabled={isScanning}
                className="w-full text-xs font-mono bg-slate-900 border border-slate-800 text-slate-200 p-2.5 rounded-lg outline-none focus:border-indigo-500 transition cursor-pointer"
              >
                {TARGETS.map(t => (
                  <option key={t.id} value={t.id}>{t.name}</option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] uppercase font-mono tracking-wider font-bold text-slate-400">
                2. Select Scan Methodology
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(["syn", "connect", "udp"] as ScanType[]).map((type) => (
                  <button
                    key={type}
                    onClick={() => setScanType(type)}
                    disabled={isScanning}
                    className={`text-xs py-2 px-1 rounded-lg border font-mono font-bold capitalize transition cursor-pointer ${
                      scanType === type
                        ? "bg-indigo-600/15 border-indigo-500 text-indigo-400"
                        : "bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    {type} scan
                  </button>
                ))}
              </div>
            </div>

            <div className="p-3 bg-slate-900 rounded-lg border border-slate-800/80 text-xs text-slate-400 space-y-1">
              <div className="flex justify-between">
                <span>Target Host:</span>
                <span className="font-mono text-white">{target.ip}</span>
              </div>
              <div className="flex justify-between">
                <span>OS Fingerprint:</span>
                <span className="font-mono text-white text-right truncate max-w-[140px]">{target.os}</span>
              </div>
            </div>
          </div>

          <button
            onClick={handleInitiateScan}
            disabled={isScanning}
            className="w-full flex items-center justify-center gap-2 py-3 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-500 text-white font-bold text-xs rounded-lg transition-all active:scale-[0.98] cursor-pointer"
          >
            {isScanning ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                Scanning Ports ({scanProgress}%)
              </>
            ) : (
              <>
                <Play className="w-4 h-4" />
                Start Educational Probe
              </>
            )}
          </button>
        </div>

        {/* Right Column: Visual packet animated channel & terminal logs */}
        <div className="lg:col-span-8 flex flex-col space-y-4">
          
          {/* Packet Exchange visualization bar */}
          <div className="bg-slate-950 border border-slate-850 p-4 rounded-xl flex flex-col justify-between min-h-[140px] relative overflow-hidden">
            <div className="text-[10px] font-mono text-slate-500 uppercase tracking-wider flex justify-between items-center">
              <span>Interactive Packet Transition Analyzer</span>
              <span className="flex items-center gap-1">
                <Activity className="w-3 h-3 text-emerald-500" />
                Live State
              </span>
            </div>

            {/* Visual Grid representing packets flying */}
            <div className="grid grid-cols-12 items-center justify-center py-4 relative z-10">
              
              {/* Scanner Block */}
              <div className="col-span-3 text-center space-y-1 flex flex-col items-center">
                <Cpu className={`w-10 h-10 p-2 rounded-lg border ${isScanning ? "border-indigo-500 bg-indigo-500/10 text-indigo-400 animate-pulse" : "border-slate-800 bg-slate-900 text-slate-400"}`} />
                <span className="text-[10px] font-mono text-slate-300">Scanner Rig</span>
                <span className="text-[8px] font-mono text-slate-500">10.0.1.12</span>
              </div>

              {/* Transit pipeline animation channel */}
              <div className="col-span-6 relative h-8 border-b-2 border-dashed border-slate-800 flex items-center justify-center">
                {animationState?.active && (
                  <div 
                    className={`absolute text-[10px] font-mono px-2 py-1 rounded border font-bold shadow-lg animate-bounce ${
                      animationState.sender === "scanner" 
                        ? "left-0 animate-[ping_2s_infinite] bg-indigo-600/20 border-indigo-500 text-indigo-300"
                        : "right-0 bg-emerald-600/20 border-emerald-500 text-emerald-300"
                    }`}
                    style={{
                      transition: "all 1s ease-in-out",
                      transform: animationState.sender === "scanner" ? "translateX(200%)" : "translateX(-200%)"
                    }}
                  >
                    {animationState.type}
                  </div>
                )}
                {!animationState?.active && (
                  <span className="text-[10px] font-mono text-slate-600 italic">No packet active</span>
                )}
              </div>

              {/* Target Server Block */}
              <div className="col-span-3 text-center space-y-1 flex flex-col items-center">
                <Server className={`w-10 h-10 p-2 rounded-lg border ${isScanning ? "border-emerald-500 bg-emerald-500/10 text-emerald-400 animate-pulse" : "border-slate-800 bg-slate-900 text-slate-400"}`} />
                <span className="text-[10px] font-mono text-slate-300">Target Node</span>
                <span className="text-[8px] font-mono text-slate-500">{target.ip}</span>
              </div>

            </div>

            {/* Live Packet Log/Status */}
            <div className="bg-slate-900/40 p-2 rounded border border-slate-850/60 text-center">
              {animationState ? (
                <div className="space-y-1">
                  <div className="text-[10px] font-mono text-indigo-400 font-bold uppercase tracking-wider">
                    {animationState.sender === "scanner" ? ">>> Client Sending Package" : "<<< Target Replying"}
                  </div>
                  <p className="text-xs text-slate-300">{animationState.desc}</p>
                  <p className="text-[9px] font-mono text-slate-500">{animationState.flags}</p>
                </div>
              ) : (
                <p className="text-xs text-slate-500 italic">Initiate scan to analyze socket packet handshakes</p>
              )}
            </div>

          </div>

          {/* Terminal Console log window */}
          <div className="bg-slate-950 rounded-xl border border-slate-850 overflow-hidden flex flex-col h-[180px]">
            <div className="bg-slate-900/80 px-4 py-2 border-b border-slate-850 flex items-center justify-between text-xs font-mono text-slate-400">
              <span className="flex items-center gap-1.5">
                <Terminal className="w-4 h-4 text-indigo-400" />
                scanner_console.log
              </span>
              <span className="text-[10px] uppercase font-bold text-indigo-500 animate-pulse">Running shell</span>
            </div>
            
            <div className="p-4 overflow-y-auto flex-1 font-mono text-xs text-slate-300 space-y-1 scrollbar-thin">
              {consoleLogs.length === 0 ? (
                <div className="text-slate-600 italic">Console output is empty. Select target and click 'Start Educational Probe'.</div>
              ) : (
                consoleLogs.map((log, idx) => (
                  <div key={idx} className={`${
                    log.includes("[+]") ? "text-emerald-400" :
                    log.includes("[-]") ? "text-slate-500" :
                    log.includes("[>]") ? "text-indigo-400" :
                    log.includes("Critical") ? "text-red-400 font-bold animate-pulse" :
                    log.includes("Starting") ? "text-indigo-500 font-bold" : "text-slate-300"
                  }`}>
                    {log}
                  </div>
                ))
              )}
              <div ref={logsEndRef} />
            </div>
          </div>

        </div>

      </div>

      {/* Interactive Scan Results & Educational Vulnerability Mapping */}
      {scanResults.length > 0 && (
        <div className="border-t border-slate-800 pt-5 space-y-4">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Activity className="w-4 h-4 text-indigo-400" />
            Vulnerability & Port Analysis Report
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-500 font-mono text-[10px] uppercase">
                  <th className="py-2.5 px-3">Port</th>
                  <th className="py-2.5 px-3">Service</th>
                  <th className="py-2.5 px-3">State</th>
                  <th className="py-2.5 px-3">Banner Grabbing Output</th>
                  <th className="py-2.5 px-3">Identified Weak Configuration & Risk</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-850 font-mono">
                {scanResults.map((result) => (
                  <tr key={result.number} className={`hover:bg-slate-950/40 transition ${
                    result.state === "open" ? "bg-slate-900/10" : "opacity-60"
                  }`}>
                    <td className="py-3 px-3 font-bold text-slate-200">{result.number}/TCP</td>
                    <td className="py-3 px-3 text-indigo-400 font-bold">{result.service}</td>
                    <td className="py-3 px-3">
                      <span className={`px-2 py-0.5 rounded font-bold uppercase text-[9px] ${
                        result.state === "open" ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" :
                        result.state === "closed" ? "bg-slate-800 text-slate-400 border border-slate-700/55" :
                        "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                      }`}>
                        {result.state}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-[11px] text-slate-400 max-w-[200px] truncate">
                      {result.banner || <span className="text-slate-600 italic">No response banner</span>}
                    </td>
                    <td className="py-3 px-3 text-[11px]">
                      {result.risk ? (
                        <span className={`font-semibold ${
                          result.risk.includes("Critical") ? "text-red-400 animate-pulse font-bold" :
                          result.risk.includes("High") ? "text-orange-400 font-bold" :
                          result.risk.includes("Medium") ? "text-amber-400" : "text-emerald-400"
                        }`}>
                          {result.risk}
                        </span>
                      ) : (
                        <span className="text-slate-600">-</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

    </div>
  );
}
