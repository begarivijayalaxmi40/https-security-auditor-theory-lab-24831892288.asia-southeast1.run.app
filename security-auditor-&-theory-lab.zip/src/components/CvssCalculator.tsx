import { useState, useMemo } from "react";
import { 
  Percent, 
  HelpCircle, 
  ShieldCheck, 
  Layers,
  Sparkles,
  Info
} from "lucide-react";

interface CvssOption {
  label: string;
  value: string;
  weight: number;
  desc: string;
}

interface CvssMetric {
  id: string;
  name: string;
  desc: string;
  options: CvssOption[];
}

const METRICS: CvssMetric[] = [
  {
    id: "AV",
    name: "Attack Vector (AV)",
    desc: "Reflects the context by which vulnerability exploitation is possible.",
    options: [
      { label: "Network (N)", value: "N", weight: 0.85, desc: "Exploitable remotely over the internet/network." },
      { label: "Adjacent (A)", value: "A", weight: 0.62, desc: "Requires local network access (e.g. Wi-Fi range/subnet)." },
      { label: "Local (L)", value: "L", weight: 0.55, desc: "Requires system access (e.g. SSH terminal, local user shell)." },
      { label: "Physical (P)", value: "P", weight: 0.20, desc: "Requires physical access to target hardware (e.g. USB port)." }
    ]
  },
  {
    id: "AC",
    name: "Attack Complexity (AC)",
    desc: "The conditions beyond the attacker's control that must exist to exploit.",
    options: [
      { label: "Low (L)", value: "L", weight: 0.77, desc: "No special conditions required. Easily and reliably exploited." },
      { label: "High (H)", value: "H", weight: 0.44, desc: "Requires active evasion, timing windows, or specific configurations." }
    ]
  },
  {
    id: "PR",
    name: "Privileges Required (PR)",
    desc: "Level of authorization required before triggering exploitation.",
    options: [
      { label: "None (N)", value: "N", weight: 0.85, desc: "Completely unauthorized. No login/credentials required." },
      { label: "Low (L)", value: "L", weight: 0.62, desc: "Requires standard guest or authenticated user account privileges." },
      { label: "High (H)", value: "H", weight: 0.27, desc: "Requires administrative, root, or full superuser access." }
    ]
  },
  {
    id: "UI",
    name: "User Interaction (UI)",
    desc: "Requires active assistance from a legitimate target user.",
    options: [
      { label: "None (N)", value: "N", weight: 0.85, desc: "No user interaction needed. Zero-click exploitation." },
      { label: "Required (R)", value: "R", weight: 0.62, desc: "Requires the user to click a link, open a file, or enter data." }
    ]
  },
  {
    id: "S",
    name: "Scope (S)",
    desc: "Whether the vulnerability affects components beyond its security authority.",
    options: [
      { label: "Unchanged (U)", value: "U", weight: 1.0, desc: "Vulnerability only impacts the immediate sandboxed container or library." },
      { label: "Changed (C)", value: "C", weight: 1.0, desc: "Vulnerability allows sandbox escape, impacting operating system or cloud host." }
    ]
  },
  {
    id: "C",
    name: "Confidentiality (C)",
    desc: "Impact on data privacy and read permissions.",
    options: [
      { label: "High (H)", value: "H", weight: 0.56, desc: "Total disclosure of all file vaults, user directories, or secrets." },
      { label: "Low (L)", value: "L", weight: 0.22, desc: "Partial data exposure (some metadata or minor tables leaked)." },
      { label: "None (N)", value: "N", weight: 0.00, desc: "Zero confidentiality impact." }
    ]
  },
  {
    id: "I",
    name: "Integrity (I)",
    desc: "Impact on data trust, modifications, and write permissions.",
    options: [
      { label: "High (H)", value: "H", weight: 0.56, desc: "Attacker can modify any database, inject code, or wipe entire systems." },
      { label: "Low (L)", value: "L", weight: 0.22, desc: "Partial file tampering or defacement possible, but core state intact." },
      { label: "None (N)", value: "N", weight: 0.00, desc: "Zero integrity impact." }
    ]
  },
  {
    id: "A",
    name: "Availability (A)",
    desc: "Impact on service uptime, CPU load, and offline crash states.",
    options: [
      { label: "High (H)", value: "H", weight: 0.56, desc: "Complete service blackout (CPU exhaust, database wipe, crash loop)." },
      { label: "Low (L)", value: "L", weight: 0.22, desc: "Degraded performance or transient lag, but server recovers." },
      { label: "None (N)", value: "N", weight: 0.00, desc: "Zero availability impact." }
    ]
  }
];

export default function CvssCalculator() {
  const [selections, setSelections] = useState<Record<string, string>>({
    AV: "N",
    AC: "L",
    PR: "N",
    UI: "N",
    S: "U",
    C: "H",
    I: "H",
    A: "H"
  });

  const handleSelectOption = (metricId: string, optionValue: string) => {
    setSelections((prev) => ({
      ...prev,
      [metricId]: optionValue
    }));
  };

  // Calculate CVSS score using a highly faithful mathematical representation of CVSS v3.1 specs
  const results = useMemo(() => {
    const weights: Record<string, number> = {};
    
    METRICS.forEach((m) => {
      const selectedOpt = m.options.find((o) => o.value === selections[m.id]);
      weights[m.id] = selectedOpt ? selectedOpt.weight : 0;
    });

    const scopeChanged = selections.S === "C";

    // 1. Exploitability calculations
    // Adjust PR weight based on Scope change in official specs
    let prWeight = weights.PR;
    if (scopeChanged) {
      if (selections.PR === "L") prWeight = 0.68;
      if (selections.PR === "H") prWeight = 0.50;
    }

    const exploitability = 8.22 * weights.AV * weights.AC * prWeight * weights.UI;

    // 2. Impact Sub-score equations
    const iss = 1 - (1 - weights.C) * (1 - weights.I) * (1 - weights.A);
    let impact = 0;
    if (!scopeChanged) {
      impact = 6.42 * iss;
    } else {
      impact = 7.52 * (iss - 0.029) - 3.25 * Math.pow(iss - 0.02, 15);
    }

    // 3. Rounding CVSS rules (official specifications require Roundup function)
    let baseScore = 0;
    if (iss > 0) {
      if (!scopeChanged) {
        baseScore = Math.min(impact + exploitability, 10);
      } else {
        baseScore = Math.min(1.08 * (impact + exploitability), 10);
      }
    }

    // Mathematical precision roundup to 1 decimal place
    const finalScore = Math.ceil(baseScore * 10) / 10;

    // Determine severity bucket
    let tier: "NONE" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL" = "NONE";
    let color = "bg-slate-800 text-slate-500 border-slate-700";
    if (finalScore >= 0.1 && finalScore <= 3.9) {
      tier = "LOW";
      color = "bg-blue-500/10 text-blue-400 border-blue-500/30";
    } else if (finalScore >= 4.0 && finalScore <= 6.9) {
      tier = "MEDIUM";
      color = "bg-amber-500/10 text-amber-400 border-amber-500/30";
    } else if (finalScore >= 7.0 && finalScore <= 8.9) {
      tier = "HIGH";
      color = "bg-orange-500/10 text-orange-400 border-orange-500/30";
    } else if (finalScore >= 9.0) {
      tier = "CRITICAL";
      color = "bg-red-500/15 text-red-400 border-red-500/30 font-bold";
    }

    // Generate standardized CVSS Vector string
    const vectorStr = `CVSS:3.1/AV:${selections.AV}/AC:${selections.AC}/PR:${selections.PR}/UI:${selections.UI}/S:${selections.S}/C:${selections.C}/I:${selections.I}/A:${selections.A}`;

    return {
      score: finalScore === 0 ? 0.0 : finalScore,
      tier,
      color,
      vector: vectorStr,
      exploitability: Math.round(exploitability * 10) / 10,
      impact: Math.round(impact * 10) / 10
    };
  }, [selections]);

  return (
    <div id="cvss-calculator" className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-500/10 rounded-lg">
            <Percent className="w-5 h-5 text-indigo-400" />
          </div>
          <div>
            <h2 className="text-xl font-bold tracking-tight text-white">CVSS v3.1 Threat Calculator</h2>
            <p className="text-xs text-slate-400">Calculate vulnerability severity metrics based on standard vectors</p>
          </div>
        </div>

        <div className="flex items-center gap-1 text-[10px] font-mono bg-slate-950 border border-slate-850 px-3 py-1.5 rounded-lg text-slate-400">
          <span>Formula Version:</span>
          <span className="text-indigo-400 font-bold">NIST / FIRST v3.1 compliant</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Metric selection matrix */}
        <div className="lg:col-span-8 space-y-4">
          <div className="text-[10px] font-mono uppercase tracking-wider text-slate-500 font-bold">
            Vulnerability Vector Matrix
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {METRICS.map((metric) => (
              <div key={metric.id} className="bg-slate-950 p-4 rounded-xl border border-slate-850/60 space-y-2.5">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-bold text-xs text-slate-200">{metric.name}</h4>
                    <p className="text-[10px] text-slate-500 font-sans leading-tight mt-0.5">{metric.desc}</p>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-1">
                  {metric.options.map((opt) => {
                    const isSelected = selections[metric.id] === opt.value;
                    return (
                      <button
                        key={opt.value}
                        onClick={() => handleSelectOption(metric.id, opt.value)}
                        className={`text-[11px] py-1.5 px-1.5 rounded-lg border font-medium text-center transition cursor-pointer flex flex-col justify-between h-[52px] ${
                          isSelected
                            ? "bg-indigo-600/15 border-indigo-500 text-indigo-400"
                            : "bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200"
                        }`}
                        title={opt.desc}
                      >
                        <span className="font-bold block text-left truncate w-full">{opt.label}</span>
                        <span className="text-[8px] opacity-70 block text-left leading-normal text-slate-500 truncate">{opt.desc}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Dynamic score summary reports */}
        <div className="lg:col-span-4 bg-slate-950/80 border border-slate-850 rounded-xl p-5 flex flex-col justify-between self-stretch">
          
          <div className="space-y-4">
            <div className="text-[10px] font-mono uppercase tracking-wider text-slate-500 font-bold">
              Generated Severity Audit
            </div>

            {/* Score Ring Display */}
            <div className="bg-slate-900 p-5 rounded-xl border border-slate-800 text-center space-y-2 relative overflow-hidden">
              <div className="text-[9px] uppercase font-mono tracking-wider text-slate-500">Calculated Threat Rating</div>
              
              <div className="text-4xl font-black font-mono text-white flex items-center justify-center gap-1.5">
                {results.score.toFixed(1)}
                <span className="text-sm font-normal text-slate-500">/ 10</span>
              </div>

              <div className="inline-block">
                <span className={`text-[10px] uppercase font-mono tracking-wider px-2.5 py-0.5 rounded-full border ${results.color}`}>
                  {results.tier} Severity
                </span>
              </div>

              <div className="text-[9px] text-slate-400 font-sans border-t border-slate-850/60 pt-2 leading-relaxed">
                Score calculates how easily a vulnerability can be utilized and how severe the data impact is.
              </div>
            </div>

            {/* Sub-scores */}
            <div className="grid grid-cols-2 gap-3 font-mono">
              <div className="bg-slate-900 p-3 rounded-lg border border-slate-850 text-center">
                <div className="text-[8px] text-slate-500 uppercase tracking-tight">Exploitability</div>
                <div className="text-xs font-bold text-slate-300">{results.exploitability} / 10</div>
              </div>
              <div className="bg-slate-900 p-3 rounded-lg border border-slate-850 text-center">
                <div className="text-[8px] text-slate-500 uppercase tracking-tight">Impact Subscore</div>
                <div className="text-xs font-bold text-slate-300">{results.impact} / 10</div>
              </div>
            </div>
          </div>

          {/* Standard vector string block */}
          <div className="space-y-2.5 pt-4 border-t border-slate-850">
            <div className="text-[10px] font-mono uppercase tracking-wider text-slate-500 font-bold flex justify-between">
              <span>NIST Standard Vector</span>
              <span className="text-[9px] text-indigo-400 capitalize">NVD Compatible</span>
            </div>

            <div className="bg-slate-900 p-3 rounded-lg border border-slate-850 font-mono text-[9px] text-indigo-400 break-all select-all leading-normal">
              {results.vector}
            </div>

            {/* Severity Guideline helper card */}
            <div className="bg-indigo-500/5 border border-indigo-950/40 p-3.5 rounded-xl flex items-start gap-2.5">
              <Info className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
              <p className="text-[10px] text-slate-400 leading-normal">
                CVSS scores are critical when prioritizing security patches. Anything above a **9.0 (Critical)** must trigger immediate emergency triage.
              </p>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
