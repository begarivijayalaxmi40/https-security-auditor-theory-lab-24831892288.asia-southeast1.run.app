import { useState, useMemo } from "react";
import { 
  FileText, 
  Play, 
  ShieldCheck, 
  ShieldAlert, 
  AlertCircle, 
  Check, 
  Copy, 
  FileCode, 
  Info,
  ChevronRight,
  Code
} from "lucide-react";
import { PresetConfig, SecurityVulnerability, SeverityType } from "../types";

// Static vulnerability scanning rules (regex-based for safe browser execution)
const AUDIT_RULES = [
  // 1. Secret Keys and Credentials in Configs
  {
    regex: /(password|passwd|secret_key|api_key|db_password|private_key)\s*=\s*['"]?([a-zA-Z0-9_-]{3,})['"]?/i,
    test: (line: string) => {
      const match = line.match(/(password|passwd|secret_key|api_key|db_password|private_key)\s*=\s*['"]?([^'"\s]{3,})['"]?/i);
      if (match) {
        const value = match[2].toLowerCase();
        // Ignore placeholders
        if (value.includes("your") || value.includes("placeholder") || value.includes("my_") || value === "env_var") {
          return false;
        }
        return true;
      }
      return false;
    },
    title: "Hardcoded Credential Exposure",
    severity: "critical" as SeverityType,
    category: "authentication",
    description: "Embedding production passwords, database credentials, or secret keys directly in configuration files exposes secrets to anybody with read access. If committed to version control, it compromises the entire infrastructure.",
    owaspMapping: "A02:2021-Cryptographic Failures",
    remediation: "Remove the hardcoded secret and load it dynamically at runtime via secure environment variables (e.g. process.env) sourced from an encrypted vault like Vault or AWS Secret Manager."
  },
  // 2. Outdated Base Images in Dockerfiles
  {
    regex: /FROM\s+(node:1[0-4]|python:3\.[5-8]|ubuntu:1[468]\.04|alpine:3\.[0-9]\b)/i,
    test: (line: string) => /FROM\s+(node:1[0-4]|python:3\.[5-8]|ubuntu:1[468]\.04|alpine:3\.[0-9]\b)/i.test(line),
    title: "Obsolete & Vulnerable Base Image",
    severity: "high" as SeverityType,
    category: "dependency",
    description: "The Dockerfile relies on an obsolete, unpatched base image. Older operating system releases contain hundreds of publicly cataloged CVEs including heartbleed, shellshock, or kernel privilege escalations.",
    owaspMapping: "A06:2021-Vulnerable and Outdated Components",
    remediation: "Upgrade the base image reference to the latest LTS (Long Term Support) release or minimal container footprint (e.g., node:20-alpine or alpine:3.19)."
  },
  // 3. Overprivileged Docker containers running as root
  {
    regex: /USER\s+root/i,
    test: (line: string) => /USER\s+root/i.test(line),
    title: "Privileged Execution Container (Root Access)",
    severity: "medium" as SeverityType,
    category: "privilege",
    description: "Running a container service as root is a major privilege-escalation risk. In the event of a remote code execution (RCE) vulnerability inside the application, the attacker inherits full root privileges over the host filesystem via container breakout.",
    owaspMapping: "A05:2021-Security Misconfiguration",
    remediation: "Create a dedicated low-privileged system user within your Dockerfile and switch contexts using the USER instruction before launch (e.g. USER node or USER appuser)."
  },
  // 4. Insecure TLS / SSL protocols in Nginx
  {
    regex: /ssl_protocols\s+([^;]+)/i,
    test: (line: string) => {
      const match = line.match(/ssl_protocols\s+([^;]+)/i);
      if (match) {
        const protocols = match[1].toLowerCase();
        return protocols.includes("tlsv1.0") || protocols.includes("tlsv1.1") || protocols.includes("tlsv1") || protocols.includes("sslv3");
      }
      return false;
    },
    title: "Weak/Obsolescent TLS Protocol Suite",
    severity: "high" as SeverityType,
    category: "cryptography",
    description: "Allowing SSLv3, TLSv1.0, or TLSv1.1 allows attackers to execute cipher-downgrade attacks (like POODLE or BEAST) to intercept, decrypt, and tamper with secure web traffic.",
    owaspMapping: "A02:2021-Cryptographic Failures",
    remediation: "Deprecate TLS v1.0 and v1.1. Explicitly configure Nginx to require modern cryptographic protocol suites: 'ssl_protocols TLSv1.2 TLSv1.3;'."
  },
  // 5. Nginx Directory Listing Autoindex Enabled
  {
    regex: /autoindex\s+on/i,
    test: (line: string) => /autoindex\s+on/i.test(line),
    title: "Nginx Directory Traversal / Information Leak",
    severity: "medium" as SeverityType,
    category: "configuration",
    description: "Setting autoindex to 'on' forces Nginx to generate and serve index layouts of directories missing an index.html file. This exposes backends, raw source assets, logfiles, and internal directories to open crawling.",
    owaspMapping: "A01:2021-Broken Access Control",
    remediation: "Disable Nginx directory listings unless explicitly required: 'autoindex off;'."
  },
  // 6. Insecure package.json library versions
  {
    regex: /"(lodash|express|moment|axios)"\s*:\s*"[\^~]?(4\.17\.(?:[0-9]|1[0-4])|4\.16\.[0-4]|2\.24\.0|0\.21\.1)"/i,
    test: (line: string) => /"(lodash|express|moment|axios)"\s*:\s*"[\^~]?(4\.17\.(?:[0-9]|1[0-4])|4\.16\.[0-4]|2\.24\.0|0\.21\.1)"/i.test(line),
    title: "Known Vulnerable Outdated NPM Dependency",
    severity: "high" as SeverityType,
    category: "dependency",
    description: "The specified library version contains publicly disclosed critical-severity security bugs (e.g. Lodash Prototype Pollution CVE-2020-8203, Express ReDoS, or Axios Server-Side Request Forgery).",
    owaspMapping: "A06:2021-Vulnerable and Outdated Components",
    remediation: "Run 'npm audit fix' or manually upgrade the dependencies to safe, modern patches (e.g. lodash ^4.17.21, express ^4.20.0)."
  },
  // 7. Security Headers Absent in Nginx (Evaluated collectively but triggered if missing headers config block)
  {
    regex: /server\s*{/i,
    test: (line: string) => false, // Handled separately via global file scan
    title: "Missing HTTP Security Defenses",
    severity: "low" as SeverityType,
    category: "configuration",
    description: "Missing standard HTTP browser security instructions (Content-Security-Policy, X-Frame-Options, X-Content-Type-Options). This opens the application to Cross-Site Scripting (XSS), Clickjacking, and MIME sniffing attacks.",
    owaspMapping: "A05:2021-Security Misconfiguration",
    remediation: "Inject appropriate security response headers: add_header Content-Security-Policy \"default-src 'self'\"; add_header X-Frame-Options \"DENY\"; add_header X-Content-Type-Options \"nosniff\";"
  }
];

const PRESETS: PresetConfig[] = [
  {
    id: "dockerfile",
    name: "Overprivileged Dockerfile",
    filename: "Dockerfile",
    content: `# Build container environment
FROM node:12.18.0

# Set primary metadata
LABEL maintainer="admin@vulnerable-stack.io"
LABEL version="1.0.0"

# Set default server variables (Baking secrets into image)
ENV NODE_ENV=production
ENV DB_PASSWORD="secure_root_password_2026"
ENV API_KEY="sk_live_51M08fE28V93_private"

# Set layout context
WORKDIR /usr/src/app

# Copy system scripts
COPY package*.json ./

# Expose admin scripts
RUN npm install

# Copy application assets
COPY . .

# Run as superuser (Vulnerable practice)
USER root

EXPOSE 3000
CMD ["npm", "start"]`
  },
  {
    id: "nginx",
    name: "Weak Nginx Config",
    filename: "nginx.conf",
    content: `user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log warn;
pid /var/run/nginx.pid;

events {
    worker_connections 1024;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    server {
        listen 80;
        listen 443 ssl;
        server_name dev-intranet.local;

        ssl_certificate /etc/ssl/certs/dev.crt;
        ssl_certificate_key /etc/ssl/private/dev.key;

        # Vulnerable Protocol Suite (Obsolete TLS)
        ssl_protocols SSLv3 TLSv1 TLSv1.1;
        ssl_ciphers HIGH:!aNULL:!MD5;

        # Expose file directories (Directory Traversal)
        location /backups {
            alias /var/www/backups/;
            autoindex on;
        }

        location / {
            root /usr/share/nginx/html;
            index index.html index.htm;
        }
    }`
  },
  {
    id: "packagejson",
    name: "Outdated Package Manifest",
    filename: "package.json",
    content: `{
  "name": "corporate-portal-backend",
  "version": "1.4.2",
  "private": true,
  "scripts": {
    "start": "node server.js",
    "dev": "nodemon server.js"
  },
  "dependencies": {
    "axios": "^0.21.1",
    "dotenv": "^8.2.0",
    "express": "^4.16.2",
    "helmet": "^3.23.3",
    "lodash": "^4.17.11",
    "moment": "2.24.0"
  }
}`
  }
];

export default function ConfigAuditor() {
  const [selectedPresetId, setSelectedPresetId] = useState<string>("dockerfile");
  const [editorContent, setEditorContent] = useState<string>(PRESETS[0].content);
  const [audited, setAudited] = useState<boolean>(false);
  const [activeVulnerability, setActiveVulnerability] = useState<SecurityVulnerability | null>(null);
  const [copiedVulnerabilityId, setCopiedVulnerabilityId] = useState<string | null>(null);

  // Set selected preset
  const handleSelectPreset = (id: string) => {
    const preset = PRESETS.find(p => p.id === id);
    if (preset) {
      setSelectedPresetId(id);
      setEditorContent(preset.content);
      setAudited(false);
      setActiveVulnerability(null);
    }
  };

  // Run the static parser on the config content
  const auditReport = useMemo(() => {
    if (!audited) return null;

    const lines = editorContent.split("\n");
    const foundIssues: SecurityVulnerability[] = [];

    // Check line by line
    lines.forEach((lineText, idx) => {
      const lineNum = idx + 1;
      
      AUDIT_RULES.forEach((rule) => {
        // Skip HTTP Security Headers check here (evaluated globally)
        if (rule.title === "Missing HTTP Security Defenses") return;

        if (rule.test(lineText)) {
          foundIssues.push({
            id: `issue_${idx}_${rule.title.replace(/\s+/g, "_")}`,
            line: lineNum,
            codeSnippet: lineText.trim(),
            title: rule.title,
            description: rule.description,
            severity: rule.severity,
            category: rule.category as any,
            owaspMapping: rule.owaspMapping,
            remediation: rule.remediation
          });
        }
      });
    });

    // Global file level validation: Missing Security Headers in Nginx config
    if (selectedPresetId === "nginx" && !editorContent.toLowerCase().includes("content-security-policy")) {
      foundIssues.push({
        id: "nginx_missing_csp",
        title: "Missing HTTP Content-Security-Policy Header",
        description: "The Content-Security-Policy (CSP) response header helps prevent Cross-Site Scripting (XSS), clickjacking, and code injection attacks by restricting the origins from which assets (such as scripts, styles, or frames) can be loaded.",
        severity: "medium",
        category: "configuration",
        owaspMapping: "A05:2021-Security Misconfiguration",
        remediation: "Add the CSP configuration header directive inside the server block of Nginx:\nadd_header Content-Security-Policy \"default-src 'self'; script-src 'self' 'unsafe-inline';\";"
      });
    }

    if (selectedPresetId === "nginx" && !editorContent.toLowerCase().includes("x-frame-options")) {
      foundIssues.push({
        id: "nginx_missing_clickjacking",
        title: "Missing X-Frame-Options Protection",
        description: "The X-Frame-Options HTTP response header is missing. This exposes your users to Clickjacking attacks, where an attacker embeds your site inside an iframe on an external malicious site to hijack clicks.",
        severity: "low",
        category: "configuration",
        owaspMapping: "A05:2021-Security Misconfiguration",
        remediation: "Prevent the site from being framed by injecting this header into your Nginx config:\nadd_header X-Frame-Options \"DENY\";"
      });
    }

    // Calculate score (out of 100)
    let score = 100;
    foundIssues.forEach((issue) => {
      if (issue.severity === "critical") score -= 25;
      else if (issue.severity === "high") score -= 15;
      else if (issue.severity === "medium") score -= 10;
      else score -= 5;
    });
    const finalScore = Math.max(0, score);

    return {
      vulnerabilities: foundIssues,
      score: finalScore,
      scannedLines: lines.length
    };
  }, [editorContent, audited, selectedPresetId]);

  const copyToClipboard = async (text: string, id: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedVulnerabilityId(id);
      setTimeout(() => setCopiedVulnerabilityId(null), 2000);
    } catch (e) {
      console.error(e);
    }
  };

  const getSeverityStyle = (severity: SeverityType) => {
    switch (severity) {
      case "critical": return "bg-red-500/10 text-red-400 border-red-500/30";
      case "high": return "bg-orange-500/10 text-orange-400 border-orange-500/30";
      case "medium": return "bg-amber-500/10 text-amber-400 border-amber-500/30";
      case "low": return "bg-blue-500/10 text-blue-400 border-blue-500/30";
    }
  };

  return (
    <div id="configuration-auditor" className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl space-y-6">
      
      {/* Module Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-500/10 rounded-lg">
            <FileText className="w-5 h-5 text-indigo-400" />
          </div>
          <div>
            <h2 className="text-xl font-bold tracking-tight text-white">Static Configuration Auditor</h2>
            <p className="text-xs text-slate-400">Scan Nginx, Dockerfiles, and dependencies for security flaws</p>
          </div>
        </div>

        {/* Presets Selectors */}
        <div className="flex gap-1.5 flex-wrap">
          {PRESETS.map((preset) => (
            <button
              key={preset.id}
              onClick={() => handleSelectPreset(preset.id)}
              className={`text-xs px-3 py-1.5 rounded-lg border font-medium transition cursor-pointer ${
                selectedPresetId === preset.id
                  ? "bg-indigo-600 border-indigo-500 text-white"
                  : "bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-900"
              }`}
            >
              {preset.name}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        
        {/* Editor and Scan Button Section */}
        <div className="xl:col-span-7 flex flex-col space-y-4">
          <div className="relative rounded-xl border border-slate-850 bg-slate-950 overflow-hidden flex-1 flex flex-col min-h-[380px]">
            {/* Filename tab bar */}
            <div className="bg-slate-900/60 px-4 py-2 border-b border-slate-850 flex items-center justify-between text-xs font-mono text-slate-400">
              <span className="flex items-center gap-1.5">
                <FileCode className="w-4 h-4 text-slate-400" />
                {PRESETS.find(p => p.id === selectedPresetId)?.filename || "custom_config.conf"}
              </span>
              <span className="text-[10px] text-slate-500 uppercase tracking-wider">Interactive Playground</span>
            </div>

            {/* Config text editor input */}
            <textarea
              value={editorContent}
              onChange={(e) => {
                setEditorContent(e.target.value);
                setAudited(false);
              }}
              className="w-full flex-1 p-4 bg-transparent text-slate-300 font-mono text-xs leading-relaxed outline-none resize-none overflow-y-auto"
              placeholder="Paste or write your server config/code here to scan..."
              spellCheck={false}
            />

            {/* Run Scan Action Tray */}
            <div className="bg-slate-900/40 p-3 border-t border-slate-850 flex justify-between items-center">
              <div className="text-[10px] text-slate-500 flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5" />
                You can edit the text to test custom rule patches!
              </div>

              <button
                onClick={() => setAudited(true)}
                className="flex items-center gap-2 text-xs font-bold px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition-all cursor-pointer shadow-md shadow-indigo-950/20 active:scale-95"
              >
                <Play className="w-3.5 h-3.5" />
                Audit Configuration
              </button>
            </div>
          </div>
        </div>

        {/* Audit Report and Results */}
        <div className="xl:col-span-5 flex flex-col bg-slate-950/40 border border-slate-850 rounded-xl p-5 min-h-[380px]">
          {!audited ? (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-8 space-y-4">
              <div className="p-3 bg-slate-900 rounded-full border border-slate-800">
                <ShieldCheck className="w-8 h-8 text-slate-500" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-slate-300">Ready for Static Audit</h3>
                <p className="text-xs text-slate-500 max-w-[280px] mx-auto mt-1 leading-normal">
                  Click "Audit Configuration" to parse the files line-by-line against security rules and vulnerability tables.
                </p>
              </div>
            </div>
          ) : auditReport ? (
            <div className="flex-1 flex flex-col justify-between space-y-5">
              
              {/* Header metrics card */}
              <div className="flex justify-between items-center border-b border-slate-850 pb-4">
                <div>
                  <h3 className="font-bold text-sm text-white">Compliance Report</h3>
                  <div className="text-[10px] font-mono text-slate-500">
                    Scanned {auditReport.scannedLines} Lines ➔ Found {auditReport.vulnerabilities.length} Issues
                  </div>
                </div>

                {/* Score rating circle */}
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <div className="text-[10px] text-slate-500 uppercase font-mono tracking-wider">Health Rating</div>
                    <div className={`text-base font-bold font-mono ${
                      auditReport.score >= 80 ? "text-emerald-400" : auditReport.score >= 50 ? "text-amber-400" : "text-red-400"
                    }`}>
                      {auditReport.score}/100
                    </div>
                  </div>
                  {auditReport.score === 100 ? (
                    <div className="p-1.5 bg-emerald-500/10 rounded-full border border-emerald-500/30">
                      <ShieldCheck className="w-5 h-5 text-emerald-400" />
                    </div>
                  ) : (
                    <div className="p-1.5 bg-red-500/10 rounded-full border border-red-500/30">
                      <ShieldAlert className="w-5 h-5 text-red-400" />
                    </div>
                  )}
                </div>
              </div>

              {/* Vulnerabilities Scroll Area */}
              <div className="flex-1 overflow-y-auto max-h-[240px] space-y-2 pr-1 scrollbar-thin">
                {auditReport.vulnerabilities.length === 0 ? (
                  <div className="text-center py-10 space-y-2 text-slate-500">
                    <ShieldCheck className="w-8 h-8 text-emerald-400 mx-auto" />
                    <p className="text-xs text-slate-300 font-semibold">Config File is Clean!</p>
                    <p className="text-[11px] max-w-[240px] mx-auto">No security misconfigurations or credentials detected in our ruleset.</p>
                  </div>
                ) : (
                  auditReport.vulnerabilities.map((v) => (
                    <button
                      key={v.id}
                      onClick={() => setActiveVulnerability(v)}
                      className={`w-full text-left p-3 rounded-lg border text-xs flex justify-between items-center transition cursor-pointer ${
                        activeVulnerability?.id === v.id
                          ? "bg-slate-900 border-indigo-500 text-white"
                          : "bg-slate-950/80 border-slate-850 text-slate-400 hover:bg-slate-900/50 hover:text-slate-300"
                      }`}
                    >
                      <div className="min-w-0 pr-3 space-y-1">
                        <div className="flex items-center gap-1.5">
                          <span className={`text-[9px] uppercase px-1.5 py-0.5 rounded font-mono border font-semibold ${getSeverityStyle(v.severity)}`}>
                            {v.severity}
                          </span>
                          {v.line && (
                            <span className="text-[10px] text-indigo-400 font-mono">L{v.line}</span>
                          )}
                        </div>
                        <div className="font-semibold truncate text-slate-200">{v.title}</div>
                      </div>
                      <ChevronRight className={`w-4 h-4 shrink-0 transition-transform ${activeVulnerability?.id === v.id ? "rotate-90 text-indigo-400" : "text-slate-600"}`} />
                    </button>
                  ))
                )}
              </div>

              {/* Remediations Panel if a vulnerability is clicked */}
              {activeVulnerability && (
                <div className="bg-slate-900 border border-slate-850 rounded-xl p-4 space-y-3">
                  <div className="flex justify-between items-start gap-2">
                    <div>
                      <h4 className="font-bold text-xs text-white flex items-center gap-1">
                        <AlertCircle className="w-3.5 h-3.5 text-indigo-400" />
                        {activeVulnerability.title}
                      </h4>
                      <p className="text-[10px] text-slate-500 font-mono">{activeVulnerability.owaspMapping}</p>
                    </div>
                    <button
                      onClick={() => setActiveVulnerability(null)}
                      className="text-slate-500 hover:text-slate-300 transition text-[10px] uppercase font-mono tracking-wider cursor-pointer"
                    >
                      [close]
                    </button>
                  </div>

                  <p className="text-[11px] text-slate-400 leading-normal">
                    {activeVulnerability.description}
                  </p>

                  <div className="space-y-1 pt-1.5 border-t border-slate-850">
                    <div className="flex justify-between items-center text-[10px] font-mono text-slate-500 uppercase tracking-wider">
                      <span>Remediation Fix Code</span>
                      <button
                        onClick={() => copyToClipboard(activeVulnerability.remediation, activeVulnerability.id)}
                        className="flex items-center gap-1 text-slate-400 hover:text-white transition cursor-pointer"
                      >
                        {copiedVulnerabilityId === activeVulnerability.id ? (
                          <>
                            <Check className="w-3 h-3 text-emerald-400" />
                            <span className="text-emerald-400">Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            <span>Copy Fix</span>
                          </>
                        )}
                      </button>
                    </div>
                    <div className="bg-slate-950/80 border border-slate-800 p-2.5 rounded-md overflow-x-auto max-h-[85px]">
                      <pre className="text-[10px] font-mono text-emerald-400 select-all leading-normal whitespace-pre-wrap">
                        <code>{activeVulnerability.remediation}</code>
                      </pre>
                    </div>
                  </div>
                </div>
              )}

            </div>
          ) : null}
        </div>

      </div>

    </div>
  );
}
