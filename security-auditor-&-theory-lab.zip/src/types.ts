// Core type definitions for the Security Auditor & Theory Lab

export type SeverityType = "critical" | "high" | "medium" | "low";

export interface SecurityVulnerability {
  id: string;
  line?: number;
  codeSnippet?: string;
  title: string;
  description: string;
  severity: SeverityType;
  category: "authentication" | "configuration" | "dependency" | "logging" | "cryptography" | "privilege";
  cveReference?: string;
  owaspMapping: string;
  remediation: string;
}

export interface AuditResult {
  vulnerabilities: SecurityVulnerability[];
  score: number; // Defensive health rating (0 to 100)
  scannedLines: number;
}

export interface PresetConfig {
  id: string;
  name: string;
  filename: string;
  content: string;
}

export interface PortScanTarget {
  id: string;
  ip: string;
  name: string;
  os: string;
  ports: {
    number: number;
    service: string;
    state: "open" | "closed" | "filtered";
    banner?: string;
    vulnerabilities: string[];
  }[];
}

export interface HistoricalCve {
  id: string;
  cveId: string;
  title: string;
  year: number;
  cvss: number;
  description: string;
  vulnerableCode: string;
  patchedCode: string;
  explanation: string;
  remediation: string;
}

export type ScanType = "syn" | "connect" | "udp";
export type PacketType = "SYN" | "SYN-ACK" | "ACK" | "RST" | "UDP" | "ICMP_UNREACH" | "TIMEOUT";

export interface PacketAnimationState {
  step: number;
  sender: "scanner" | "target";
  type: PacketType;
  flags: string;
  desc: string;
  active: boolean;
}
