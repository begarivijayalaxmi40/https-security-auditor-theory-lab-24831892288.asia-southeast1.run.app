import { useState, useEffect } from "react";
import { 
  Eye, 
  EyeOff, 
  ShieldCheck, 
  ShieldAlert, 
  Lock, 
  AlertTriangle, 
  X, 
  CheckCircle2, 
  XCircle, 
  HelpCircle, 
  Info, 
  Zap, 
  Check, 
  Copy 
} from "lucide-react";
import { calculateEntropy, getBruteForceTime, checkHaveIBeenPwned, COMMON_WEAK_PASSWORDS } from "./utils/crypto";
import SecurityAcademy from "./components/SecurityAcademy";
import PasswordGenerator from "./components/PasswordGenerator";
import DatabaseSimulator from "./components/DatabaseSimulator";
import { motion, AnimatePresence } from "motion/react";

export default function App() {
  const [password, setPassword] = useState<string>("");
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [isReused, setIsReused] = useState<boolean>(false);

  // Leak state
  const [pwnedCount, setPwnedCount] = useState<number>(0);
  const [checkingPwned, setCheckingPwned] = useState<boolean>(false);
  const [copiedText, setCopiedText] = useState<boolean>(false);

  // Leak checking with debounce
  useEffect(() => {
    if (!password) {
      setPwnedCount(0);
      setCheckingPwned(false);
      return;
    }

    setCheckingPwned(true);
    const debounceTimeout = setTimeout(async () => {
      const leaks = await checkHaveIBeenPwned(password);
      setPwnedCount(leaks);
      setCheckingPwned(false);
    }, 600); // Debounce lookup to protect server & match typing flow

    return () => clearTimeout(debounceTimeout);
  }, [password]);

  // Basic criteria checks
  const isLengthValid = password.length >= 12;
  const hasLowercase = /[a-z]/.test(password);
  const hasUppercase = /[A-Z]/.test(password);
  const hasDigit = /[0-9]/.test(password);
  const hasSpecial = /[^A-Za-z0-9]/.test(password);
  const isCommon = COMMON_WEAK_PASSWORDS.includes(password.toLowerCase());
  const isLeaked = pwnedCount > 0;

  // Real-time strength score calculation (0 to 100)
  const calculateScore = (): number => {
    if (!password) return 0;
    
    let score = 0;

    // 1. Length contribution (up to 40 points)
    // 1 point per char up to 10, then 3 points per char up to 20
    const len = password.length;
    if (len <= 10) {
      score += len * 2.5; 
    } else {
      score += 25 + (len - 10) * 1.5;
    }
    score = Math.min(score, 40);

    // 2. Character diversity contribution (up to 40 points)
    if (hasLowercase) score += 10;
    if (hasUppercase) score += 10;
    if (hasDigit) score += 10;
    if (hasSpecial) score += 10;

    // 3. Entropy contribution (up to 20 points)
    const { entropy } = calculateEntropy(password);
    if (entropy >= 50) score += 10;
    if (entropy >= 80) score += 10;

    // Deductions
    if (isCommon) {
      score -= 50;
    }
    if (isLeaked) {
      // Deduct proportionally based on how severely leaked it is
      score -= pwnedCount > 1000 ? 60 : 40;
    }
    if (isReused) {
      score -= 30;
    }

    // Cap between 0 and 100
    return Math.max(0, Math.min(100, Math.round(score)));
  };

  const score = calculateScore();

  // Determine strength parameters
  const getStrengthTier = (score: number) => {
    if (!password) return { label: "No Password", color: "bg-slate-800 text-slate-500 border-slate-700", fill: "bg-slate-700", textColor: "text-slate-500" };
    if (score < 25) return { label: "Very Weak", color: "bg-red-500/10 text-red-400 border-red-500/30", fill: "bg-red-500", textColor: "text-red-400" };
    if (score < 50) return { label: "Weak", color: "bg-orange-500/10 text-orange-400 border-orange-500/30", fill: "bg-orange-500", textColor: "text-orange-400" };
    if (score < 75) return { label: "Moderate", color: "bg-amber-500/10 text-amber-400 border-amber-500/30", fill: "bg-amber-500", textColor: "text-amber-400" };
    if (score < 90) return { label: "Strong", color: "bg-emerald-500/10 text-emerald-400 border-emerald-500/30", fill: "bg-emerald-500", textColor: "text-emerald-400" };
    return { label: "Excellent", color: "bg-teal-500/15 text-teal-400 border-teal-500/30", fill: "bg-teal-400", textColor: "text-teal-400 font-bold" };
  };

  const tier = getStrengthTier(score);
  const { entropy, poolSize, details: poolDetails } = calculateEntropy(password);
  const bruteForce = getBruteForceTime(entropy);

  const copyPasswordToClipboard = async () => {
    if (!password) return;
    try {
      await navigator.clipboard.writeText(password);
      setCopiedText(true);
      setTimeout(() => setCopiedText(false), 2000);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 font-sans selection:bg-indigo-500 selection:text-white text-slate-200">
      
      {/* Visual Header */}
      <div className="max-w-7xl mx-auto px-4 pt-10 pb-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-900 pb-6">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="inline-block w-2.5 h-2.5 bg-indigo-500 rounded-full animate-pulse"></span>
              <h1 className="text-2xl font-bold tracking-tight text-white font-mono">CRYPTOSHIELD LAB</h1>
            </div>
            <p className="text-xs text-slate-400">
              Interactive high-fidelity password strength metrics & cryptographic policy simulator
            </p>
          </div>
          <div className="flex items-center gap-2 text-[11px] font-mono bg-slate-900/60 border border-slate-800 px-3 py-1.5 rounded-lg text-slate-400">
            <span>CLIENT-SIDE ANALYSIS:</span>
            <span className="text-emerald-400 font-semibold flex items-center gap-1">
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span>
              100% SECURE & LOCAL
            </span>
          </div>
        </div>
      </div>

      {/* Main Single-Screen Bento Grid Workspace */}
      <main className="max-w-7xl mx-auto px-4 pb-16 space-y-8">
        
        {/* Core Input & Speedometer Section */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Password Entry & Analysis Checklist */}
          <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6">
            
            <div className="space-y-2">
              <label htmlFor="main-password" className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex justify-between items-center">
                <span>Enter Password to Evaluate</span>
                <span className="font-mono text-[10px] text-slate-500 lowercase">no keystrokes sent to server</span>
              </label>
              
              <div className="relative group">
                <input
                  id="main-password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Type or generate a secure password..."
                  className="w-full bg-slate-950 text-slate-100 placeholder-slate-600 font-mono text-sm sm:text-base border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-3.5 pr-28 outline-none transition-all duration-200 shadow-inner"
                />
                
                {/* Inputs actions overlay */}
                <div className="absolute right-3 top-2.5 flex items-center gap-1.5">
                  {password && (
                    <button
                      onClick={() => setPassword("")}
                      className="p-1.5 text-slate-500 hover:text-slate-300 transition hover:bg-slate-900/60 rounded-lg"
                      title="Clear password"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                  <button
                    onClick={() => setShowPassword(!showPassword)}
                    className="p-1.5 text-slate-500 hover:text-slate-300 transition hover:bg-slate-900/60 rounded-lg"
                    title={showPassword ? "Hide password" : "Show password"}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                  {password && (
                    <button
                      onClick={copyPasswordToClipboard}
                      className="p-1.5 text-slate-500 hover:text-slate-300 transition hover:bg-slate-900/60 rounded-lg"
                      title="Copy to clipboard"
                    >
                      {copiedText ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Live Strength Progress Bar */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs font-semibold">
                <span className="text-slate-400">Calculated Score</span>
                <div className="flex items-center gap-1.5">
                  <span className={`text-xs uppercase px-2 py-0.5 rounded-md font-mono ${tier.color}`}>
                    {tier.label}
                  </span>
                  <span className="font-mono text-white text-sm font-bold">{score}/100</span>
                </div>
              </div>
              <div className="w-full bg-slate-950 h-2.5 rounded-full overflow-hidden border border-slate-850">
                <div 
                  className={`h-full transition-all duration-300 ease-out rounded-full ${tier.fill}`}
                  style={{ width: `${score}%` }}
                ></div>
              </div>
            </div>

            {/* Criteria Checklist */}
            <div className="space-y-3">
              <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-500 border-b border-slate-800 pb-2">
                Defense Parameter Checklist
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                
                {/* 1. Length */}
                <div className="flex items-center gap-2.5 text-xs">
                  {isLengthValid ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  ) : (
                    <XCircle className="w-4 h-4 text-slate-600 shrink-0" />
                  )}
                  <span className={`${isLengthValid ? "text-slate-300" : "text-slate-500"}`}>
                    At least 12 characters <span className="font-mono text-[10px] text-slate-500">({password.length})</span>
                  </span>
                </div>

                {/* 2. Uppercase */}
                <div className="flex items-center gap-2.5 text-xs">
                  {hasUppercase ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  ) : (
                    <XCircle className="w-4 h-4 text-slate-600 shrink-0" />
                  )}
                  <span className={`${hasUppercase ? "text-slate-300" : "text-slate-500"}`}>
                    Uppercase characters <span className="font-mono text-[10px] text-slate-500">(A-Z)</span>
                  </span>
                </div>

                {/* 3. Lowercase */}
                <div className="flex items-center gap-2.5 text-xs">
                  {hasLowercase ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  ) : (
                    <XCircle className="w-4 h-4 text-slate-600 shrink-0" />
                  )}
                  <span className={`${hasLowercase ? "text-slate-300" : "text-slate-500"}`}>
                    Lowercase characters <span className="font-mono text-[10px] text-slate-500">(a-z)</span>
                  </span>
                </div>

                {/* 4. Numbers */}
                <div className="flex items-center gap-2.5 text-xs">
                  {hasDigit ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  ) : (
                    <XCircle className="w-4 h-4 text-slate-600 shrink-0" />
                  )}
                  <span className={`${hasDigit ? "text-slate-300" : "text-slate-500"}`}>
                    Numeric digits <span className="font-mono text-[10px] text-slate-500">(0-9)</span>
                  </span>
                </div>

                {/* 5. Special Chars */}
                <div className="flex items-center gap-2.5 text-xs">
                  {hasSpecial ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  ) : (
                    <XCircle className="w-4 h-4 text-slate-600 shrink-0" />
                  )}
                  <span className={`${hasSpecial ? "text-slate-300" : "text-slate-500"}`}>
                    Special characters <span className="font-mono text-[10px] text-slate-500">(!@#$)</span>
                  </span>
                </div>

                {/* 6. Database Check & History Policy */}
                <div className="flex items-center gap-2.5 text-xs">
                  {password && !isReused ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  ) : isReused ? (
                    <XCircle className="w-4 h-4 text-red-400 shrink-0 animate-bounce" />
                  ) : (
                    <XCircle className="w-4 h-4 text-slate-600 shrink-0" />
                  )}
                  <span className={`${password && !isReused ? "text-slate-300" : isReused ? "text-red-400 font-semibold" : "text-slate-500"}`}>
                    {isReused ? "Blocked: Used Before" : "Unique from Old History"}
                  </span>
                </div>

              </div>
            </div>

            {/* Offline Weak Database Warning */}
            {isCommon && (
              <div className="bg-red-950/20 border border-red-900/40 rounded-xl p-3.5 flex items-start gap-2.5 text-xs text-red-400">
                <AlertTriangle className="w-4.5 h-4.5 text-red-500 shrink-0 mt-0.5" />
                <div>
                  <strong className="font-bold">Severe Security Vulnerability!</strong> This password is listed in offline lists of the world's most common, dictionary-cracked passwords. Hackers can guess this instantly in any dictionary attack. Change it immediately.
                </div>
              </div>
            )}
          </div>

          {/* Right Column: Advanced Cryptographic Entropy Panel */}
          <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6 flex flex-col justify-between self-stretch">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <Zap className="w-4 h-4 text-indigo-400" />
                  Entropy & Physics Analysis
                </h3>
                <span className="text-[10px] font-mono text-slate-500">Theoretical limits</span>
              </div>

              {/* Entropy Bit Block */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 text-center space-y-1">
                  <div className="text-[10px] uppercase font-mono tracking-wider text-slate-500">Shannon Entropy</div>
                  <div className="text-2xl font-bold font-mono text-indigo-400">
                    {entropy} <span className="text-xs text-slate-400">bits</span>
                  </div>
                  <div className="text-[9px] text-slate-400 uppercase tracking-tight">Strength Gauge</div>
                </div>

                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 text-center space-y-1">
                  <div className="text-[10px] uppercase font-mono tracking-wider text-slate-500">Character Pool Size</div>
                  <div className="text-2xl font-bold font-mono text-emerald-400">
                    {poolSize} <span className="text-xs text-slate-400">options</span>
                  </div>
                  <div className="text-[9px] text-slate-400 uppercase tracking-tight">Alphabet Size (R)</div>
                </div>
              </div>

              {/* Live pool breakdown detail */}
              {password && (
                <div className="text-[11px] font-mono text-slate-400 bg-slate-950/40 p-2.5 rounded-lg border border-slate-850 flex items-center gap-1.5">
                  <Info className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                  <span>Pool Detail: {poolDetails}</span>
                </div>
              )}

              {/* Estimated Crack Time Section */}
              <div className="bg-slate-950/80 rounded-xl p-4 border border-slate-800/60 space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-xs text-slate-400">Estimated Brute Force Time</span>
                  <span className="text-[9px] font-mono bg-slate-800 px-1.5 py-0.5 rounded text-slate-400 uppercase tracking-wider">10 Billion / sec</span>
                </div>
                
                <div className={`text-lg font-bold font-mono ${bruteForce.color}`}>
                  {bruteForce.timeText}
                </div>
                
                <div className="text-xs text-slate-300 font-semibold flex items-center gap-1">
                  <span className="inline-block w-1.5 h-1.5 rounded-full bg-slate-400"></span>
                  Classified as: {bruteForce.category}
                </div>
                
                <p className="text-[11px] text-slate-400 leading-normal border-t border-slate-900 pt-2">
                  {bruteForce.description}
                </p>
              </div>
            </div>

            {/* Secure Leak Check Status Panel */}
            <div className="border-t border-slate-800 pt-5 mt-4 space-y-3">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-400">
                <span className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-indigo-400" />
                  k-Anonymity Leak Check (Pwned API)
                </span>
                {checkingPwned && (
                  <span className="text-[10px] text-slate-500 animate-pulse font-mono">Quering Range...</span>
                )}
              </div>

              {!password ? (
                <div className="text-xs text-slate-500 font-sans italic bg-slate-950/30 p-3 rounded-xl border border-slate-800/30 text-center">
                  Awaiting password entry to check leak directories
                </div>
              ) : pwnedCount === -1 ? (
                <div className="text-xs text-amber-400 bg-amber-950/20 p-3 rounded-xl border border-amber-900/30 text-center">
                  ⚠️ Leak check offline or service rate-limited.
                </div>
              ) : pwnedCount > 0 ? (
                <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-3 flex items-start gap-2.5 text-xs text-red-400">
                  <ShieldAlert className="w-5 h-5 text-red-400 shrink-0 mt-0.5 animate-pulse" />
                  <div>
                    <span className="font-bold uppercase text-red-500">BREACH DIRECTORY MATCH:</span> Leaked <strong className="font-bold text-white font-mono">{pwnedCount.toLocaleString()} times</strong> in public database breaches. This password has been fully compromised online and is stored in hacker lists. Never use this password anywhere.
                  </div>
                </div>
              ) : (
                <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-3 flex items-start gap-2.5 text-xs text-emerald-400">
                  <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold uppercase text-emerald-500">CLEAN DECILE:</span> No database breach matches found under HaveIBeenPwned's secure k-Anonymity catalog. (Checked securely via 5-character hash query).
                  </div>
                </div>
              )}
            </div>

          </div>

        </div>

        {/* Modular Grid: Alternative Generator & DB Simulator */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          
          {/* Alternative Generator Component */}
          <PasswordGenerator 
            onUseGeneratedPassword={(genPassword) => {
              setPassword(genPassword);
              setShowPassword(true);
            }} 
          />

          {/* Secure Database Simulator Component */}
          <DatabaseSimulator 
            currentPassword={password} 
            onReuseStatusChange={(reusedStatus) => setIsReused(reusedStatus)} 
          />

        </div>

        {/* Cryptography Educational Academy Section */}
        <SecurityAcademy />

      </main>

      {/* Visual footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-8 text-center text-xs text-slate-500 font-mono">
        <div className="max-w-7xl mx-auto px-4 space-y-1">
          <p>Designed for secure local password calculations in compliance with SHA-256 and Shannon Entropy.</p>
          <p>© 2026 CryptoShield Lab. Protecting data integrity through transparent cryptography guidelines.</p>
        </div>
      </footer>

    </div>
  );
}
